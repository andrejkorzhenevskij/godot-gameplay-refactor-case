extends Area2D

@export var heal_amount: int = 1
@export var max_hp: int = 4


func _ready() -> void:
	add_to_group("pickups")


func _on_body_entered(body: Node2D) -> void:
	if not body.is_in_group("player"):
		return

	body.heal(heal_amount, max_hp)
	queue_free()
