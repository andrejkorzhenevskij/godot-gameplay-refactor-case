extends CharacterBody2D

signal died
signal hp_changed(current_hp: int)
signal shape_shard_collected

@export var hp: int = 3
@export var move_speed: float = 220.0
@export var jump_velocity: float = -360.0
@export var enemy_bounce_velocity: float = -720.0
@export var enemy_bounce_forward_speed: float = 620.0
@export var damage_knockback_velocity: Vector2 = Vector2(260, -260)
@export var shape_crush_duration: float = 0.18
@export var shape_crush_cooldown: float = 0.4

@onready var _visual: Polygon2D = $Polygon2D
@onready var _air_stomp_visual: Polygon2D = $AirStompVisual
@onready var _attack_area: Area2D = $AttackArea
@onready var _attack_visual: Polygon2D = $AttackArea/AttackVisual
@onready var _animation_player: AnimationPlayer = $AnimationPlayer

var _gravity: float = ProjectSettings.get_setting("physics/2d/default_gravity")
var _control_enabled := true
var _last_move_direction: float = 1.0
var _bounce_control_lock_time := 0.0
var _attack_cooldown_remaining := 0.0
var _is_flashing := false
var _is_attacking := false
var _attack_hit_bodies: Array[Node2D] = []


func _ready() -> void:
	add_to_group("player")
	add_to_group("damageable")
	_air_stomp_visual.hide()
	_attack_area.monitoring = false
	_attack_visual.hide()
	_setup_attack_animation()
	_animation_player.animation_finished.connect(_on_animation_finished)


func _physics_process(delta: float) -> void:
	if not _control_enabled:
		velocity = Vector2.ZERO
		return

	if _attack_cooldown_remaining > 0.0:
		_attack_cooldown_remaining -= delta

	if not is_on_floor():
		velocity.y += _gravity * delta

	_update_air_stomp_visual()

	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = jump_velocity

	if Input.is_action_just_pressed("attack"):
		_start_shape_crush()

	var direction: float = Input.get_axis("move_left", "move_right")
	if not is_zero_approx(direction):
		_last_move_direction = sign(direction)
		_update_attack_direction()

	if _bounce_control_lock_time > 0.0:
		_bounce_control_lock_time -= delta
	else:
		velocity.x = direction * move_speed

	move_and_slide()
	_update_air_stomp_visual()


func take_damage_with_knockback(amount: int, from_position: Vector2, knockback_velocity: Vector2) -> void:
	if amount <= 0 or hp <= 0:
		return

	hp = max(hp - amount, 0)
	hp_changed.emit(hp)
	apply_damage_knockback(from_position, knockback_velocity)
	_flash_damage()

	if hp == 0:
		died.emit()


func take_damage(amount: int, from_position: Vector2 = global_position, knockback_velocity: Vector2 = damage_knockback_velocity) -> void:
	take_damage_with_knockback(amount, from_position, knockback_velocity)


func heal(amount: int, max_hp: int = 4) -> void:
	if amount <= 0 or hp <= 0:
		return

	hp = min(hp + amount, max_hp)
	hp_changed.emit(hp)


func collect_shape_shard() -> void:
	shape_shard_collected.emit()


func set_control_enabled(enabled: bool) -> void:
	_control_enabled = enabled
	if not _control_enabled:
		velocity = Vector2.ZERO


func bounce_from_enemy(direction: float) -> void:
	var bounce_direction := direction
	if is_zero_approx(bounce_direction):
		bounce_direction = _last_move_direction

	velocity.y = enemy_bounce_velocity
	velocity.x = sign(bounce_direction) * enemy_bounce_forward_speed
	_bounce_control_lock_time = 0.25


func _start_shape_crush() -> void:
	if _is_attacking or not _control_enabled or _attack_cooldown_remaining > 0.0:
		return

	_is_attacking = true
	_attack_cooldown_remaining = shape_crush_cooldown
	_attack_hit_bodies.clear()
	_update_attack_direction()
	_attack_area.monitoring = true
	_animation_player.stop()
	_animation_player.play("shape_crush")
	_check_attack_overlaps()


func _finish_shape_crush() -> void:
	_is_attacking = false
	_attack_area.monitoring = false
	_attack_visual.hide()
	_attack_area.scale = Vector2(sign(_last_move_direction), 1.0)
	_attack_hit_bodies.clear()
	_visual.scale = Vector2.ONE


func _setup_attack_animation() -> void:
	var animation := Animation.new()
	animation.length = shape_crush_duration

	var scale_track := animation.add_track(Animation.TYPE_VALUE)
	animation.track_set_path(scale_track, NodePath("Polygon2D:scale"))
	animation.track_insert_key(scale_track, 0.0, Vector2.ONE)
	animation.track_insert_key(scale_track, shape_crush_duration * 0.35, Vector2(1.18, 0.72))
	animation.track_insert_key(scale_track, shape_crush_duration, Vector2.ONE)

	var visual_track := animation.add_track(Animation.TYPE_VALUE)
	animation.track_set_path(visual_track, NodePath("AttackArea/AttackVisual:visible"))
	animation.track_insert_key(visual_track, 0.0, true)
	animation.track_insert_key(visual_track, shape_crush_duration * 0.75, true)
	animation.track_insert_key(visual_track, shape_crush_duration, false)

	var library := AnimationLibrary.new()
	library.add_animation("shape_crush", animation)
	_animation_player.add_animation_library("", library)


func _on_animation_finished(animation_name: StringName) -> void:
	if animation_name == &"shape_crush":
		_finish_shape_crush()


func _on_attack_area_body_entered(body: Node2D) -> void:
	_apply_attack_hit(body)


func _check_attack_overlaps() -> void:
	await get_tree().physics_frame
	if not _is_attacking:
		return

	for body in _attack_area.get_overlapping_bodies():
		_apply_attack_hit(body)


func _apply_attack_hit(body: Node2D) -> void:
	if not _is_attacking or not body.is_in_group("enemies") or not body.is_in_group("damageable"):
		return
	if _attack_hit_bodies.has(body):
		return

	_attack_hit_bodies.append(body)
	body.take_attack_damage()


func _update_attack_direction() -> void:
	var facing_direction: float = sign(_last_move_direction)
	if is_zero_approx(facing_direction):
		facing_direction = 1.0

	_attack_area.position = Vector2(facing_direction * 18.0, 18.0)
	_attack_area.scale = Vector2(facing_direction, 1.0)


func _update_air_stomp_visual() -> void:
	_air_stomp_visual.visible = not is_on_floor()


func apply_damage_knockback(from_position: Vector2, knockback_velocity: Vector2 = damage_knockback_velocity) -> void:
	var knockback_direction: float = sign(global_position.x - from_position.x)
	if is_zero_approx(knockback_direction):
		knockback_direction = _last_move_direction

	velocity.x = knockback_direction * knockback_velocity.x
	velocity.y = knockback_velocity.y
	_bounce_control_lock_time = 0.2


func _flash_damage() -> void:
	if _is_flashing:
		return

	_is_flashing = true
	var original_color := _visual.color
	_visual.color = Color(1, 0.1, 0.1, 1)
	_spawn_damage_splash()
	await get_tree().create_timer(0.15).timeout
	_visual.color = original_color
	_is_flashing = false


func _spawn_damage_splash() -> void:
	var splash := Polygon2D.new()
	splash.color = Color(1, 0, 0, 0.55)
	splash.polygon = PackedVector2Array([
		Vector2(-22, -4),
		Vector2(-6, -6),
		Vector2(0, -22),
		Vector2(6, -6),
		Vector2(22, -4),
		Vector2(8, 4),
		Vector2(12, 20),
		Vector2(0, 8),
		Vector2(-12, 20),
		Vector2(-8, 4),
	])
	add_child(splash)
	await get_tree().create_timer(0.25).timeout
	if is_instance_valid(splash):
		splash.queue_free()
