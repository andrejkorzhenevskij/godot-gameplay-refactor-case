extends CanvasLayer

const STAR_RAY_COUNT := 10
const STAR_INITIAL_PROGRESS := 3
const STAR_FILLED_COLOR := Color(0.2, 1, 0.25, 1)
const STAR_EMPTY_COLOR := Color(0.28, 0.28, 0.3, 1)

@onready var overlay: ColorRect = $Overlay
@onready var hp_label: Label = $HPLabel
@onready var game_over_label: Label = $GameOverLabel
@onready var star_meter: Node2D = $StarMeter
@onready var star_center: Polygon2D = $StarMeter/Center

var _star_progress := STAR_INITIAL_PROGRESS

func _ready() -> void:
	overlay.hide()
	game_over_label.hide()
	_build_star_meter()
	set_star_progress(_star_progress)


func set_hp(value: int) -> void:
	var hearts: Array[String] = []
	for index in range(4):
		hearts.append("♥" if index < value else "♡")

	hp_label.text = " ".join(hearts)


func add_shape_shard() -> void:
	set_star_progress(_star_progress + 1)


func set_star_progress(value: int) -> void:
	_star_progress = clampi(value, 0, STAR_RAY_COUNT)

	for index in range(STAR_RAY_COUNT):
		var ray := star_meter.get_node("Ray%02d" % index) as Polygon2D
		ray.color = STAR_FILLED_COLOR if index < _star_progress else STAR_EMPTY_COLOR

	star_center.color = STAR_FILLED_COLOR if _star_progress >= STAR_RAY_COUNT else Color(0, 0, 0, 0)


func show_red_overlay() -> void:
	overlay.color = Color(0.8, 0, 0, 0.45)
	overlay.show()


func show_light_overlay() -> void:
	overlay.color = Color(1, 1, 1, 0.35)
	overlay.show()


func show_message(text: String) -> void:
	game_over_label.text = text
	game_over_label.show()


func show_game_over() -> void:
	show_message("Game Over")


func show_you_win() -> void:
	show_light_overlay()
	show_message("You Win")


func _build_star_meter() -> void:
	if star_meter.has_node("Ray00"):
		return

	for index in range(STAR_RAY_COUNT):
		var angle := TAU * float(index) / float(STAR_RAY_COUNT) - PI / 2.0
		var ray := Polygon2D.new()
		ray.name = "Ray%02d" % index
		ray.polygon = PackedVector2Array([
			Vector2(0, -8),
			Vector2(10, -38),
			Vector2(0, -52),
			Vector2(-10, -38),
		])
		ray.rotation = angle
		star_meter.add_child(ray)
