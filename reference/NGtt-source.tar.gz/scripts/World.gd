extends Node2D
@onready var _player: CharacterBody2D = $Player
@onready var _ui := $UI

var _is_ending := false
var _waiting_for_restart := false


func _ready() -> void:
	$FallZone.add_to_group("triggers")
	$WinOrb.add_to_group("triggers")
	_ui.set_hp(_player.hp)
	_player.hp_changed.connect(_ui.set_hp)
	_player.died.connect(_on_player_died)
	_player.shape_shard_collected.connect(_ui.add_shape_shard)


func _unhandled_input(event: InputEvent) -> void:
	if _waiting_for_restart and event.is_pressed():
		get_tree().reload_current_scene()


func _on_fall_zone_body_entered(body: Node2D) -> void:
	if _is_ending or body != _player:
		return

	_is_ending = true
	_player.set_control_enabled(false)
	_ui.show_red_overlay()
	print("Ой!")
	await get_tree().create_timer(0.3).timeout
	_ui.show_game_over()
	await get_tree().create_timer(1.0).timeout
	get_tree().reload_current_scene()


func _on_win_orb_body_entered(body: Node2D) -> void:
	if _is_ending or body != _player:
		return

	_is_ending = true
	_player.set_control_enabled(false)
	_ui.show_you_win()
	await get_tree().create_timer(1.5).timeout
	get_tree().reload_current_scene()


func _on_player_died() -> void:
	if _is_ending:
		return

	_is_ending = true
	_waiting_for_restart = true
	_player.set_control_enabled(false)
	_ui.show_red_overlay()
	_ui.show_game_over()
