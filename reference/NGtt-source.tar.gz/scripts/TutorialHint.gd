extends Label

@export var visible_time: float = 15.0
@export var fade_time: float = 1.0

var _elapsed: float = 0.0


func _ready() -> void:
	modulate.a = 1.0


func _process(delta: float) -> void:
	_elapsed += delta

	if _elapsed < visible_time:
		return

	var fade_progress: float = clampf((_elapsed - visible_time) / fade_time, 0.0, 1.0)
	modulate.a = 1.0 - fade_progress

	if fade_progress >= 1.0:
		hide()
		set_process(false)
