extends StaticBody2D

@export var amplitude: float = 80.0
@export var speed: float = 1.4

var _start_position := Vector2.ZERO
var _time := 0.0


func _ready() -> void:
	_start_position = position


func _physics_process(delta: float) -> void:
	_time += delta
	position.y = _start_position.y + sin(_time * speed) * amplitude
