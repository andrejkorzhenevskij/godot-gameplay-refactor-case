extends Area2D


func _ready() -> void:
	add_to_group("pickups")


func _on_body_entered(body: Node2D) -> void:
	if not body.is_in_group("player"):
		return

	body.collect_shape_shard()
	queue_free()
